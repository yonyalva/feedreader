# Linear Digressions App

## Instructions

1. Click on the burger menu icon
2. Click on one of the four feeds links
3. Click on any of the links displayed on the screen